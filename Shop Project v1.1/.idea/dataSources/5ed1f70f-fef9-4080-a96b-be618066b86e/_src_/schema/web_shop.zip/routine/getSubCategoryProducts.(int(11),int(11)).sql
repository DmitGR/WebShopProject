CREATE PROCEDURE `getSubCategoryProducts`(IN `subCategory_id` INT(11), IN `sort` INT(11))
  BEGIN
	SELECT * , categories.id as category, subcategories.id 
    as subcategory
    FROM products
    inner join subcategories 
    ON products.subcategory_id = subcategories.id
	inner join categories 
    ON subcategories.category_id = categories.id
    where  subcategories.id = subCategory_id
    order by    
	case sort when 1 THEN products.name END DESC,
    case sort when 2 THEN products.name END ASC,
	case sort when 3 THEN products.price END DESC,
    case sort when 4 THEN products.price END ASC,
    case sort when 5 THEN products.date END DESC,
    case sort when 6 THEN products.date END ASC;        
END