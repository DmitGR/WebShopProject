CREATE PROCEDURE `getProductInfo`(IN `id` INT(11))
  BEGIN
	SELECT products.name , products.img_url, products.price, products.description,
    products.date, products.count, users.name as sellerName, users.second_name as sellerSecName,
    users.phone, users.email
    FROM products
    inner join users 
    ON products.seller_id = users.id 
    where products.id = id;
END